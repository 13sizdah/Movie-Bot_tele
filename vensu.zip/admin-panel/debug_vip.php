<?php
// صفحه دیباگ برای بررسی مشکل VIP
define('INDEX', true);
ob_start();
session_start();

// بررسی اینکه آیا کاربر لاگین است
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

require_once 'db.php';
require_once 'src/func.php';

// اطمینان از اینکه $db تعریف شده است
if (!isset($db)) {
    die('❌ اتصال به دیتابیس برقرار نشده است. لطفاً فایل db.php را بررسی کنید.');
}

$debug_info = [];
$userid = isset($_GET['userid']) ? intval($_GET['userid']) : 0;

if ($userid > 0) {
    // دریافت اطلاعات کاربر
    try {
        $sql = "SELECT * FROM sp_users WHERE userid=:userid LIMIT 1";
        $stmt = $db->prepare($sql);
        $stmt->bindValue(':userid', $userid, PDO::PARAM_INT);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            $debug_info['user_found'] = true;
            $debug_info['user_data'] = $user;
            $debug_info['vip_date_raw'] = $user['vip_date'];
            $debug_info['vip_date_int'] = intval($user['vip_date']);
            $debug_info['current_time'] = time();
            $debug_info['vip_date_valid'] = ($debug_info['vip_date_int'] > $debug_info['current_time']);
            
            // تست تابع is_vip
            $is_vip_result = is_vip($userid);
            $debug_info['is_vip_result'] = $is_vip_result;
            global $vip_days;
            $debug_info['vip_days_remaining'] = isset($vip_days) ? $vip_days : 'N/A';
        } else {
            $debug_info['user_found'] = false;
            $debug_info['error'] = 'کاربر یافت نشد';
        }
    } catch (PDOException $e) {
        $debug_info['error'] = 'خطا در دریافت اطلاعات کاربر: ' . $e->getMessage();
    }
} else {
    $debug_info['error'] = 'شناسه کاربر معتبر نیست';
}

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>دیباگ VIP</title>
    <style>
        body {
            font-family: Tahoma, Arial, sans-serif;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            border-bottom: 2px solid #4CAF50;
            padding-bottom: 10px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="number"] {
            width: 300px;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            background: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background: #45a049;
        }
        .debug-section {
            margin-top: 30px;
            padding: 15px;
            background: #f9f9f9;
            border-radius: 4px;
            border-left: 4px solid #4CAF50;
        }
        .debug-section h2 {
            margin-top: 0;
            color: #4CAF50;
        }
        .info-item {
            margin: 10px 0;
            padding: 8px;
            background: white;
            border-radius: 4px;
        }
        .info-label {
            font-weight: bold;
            color: #666;
        }
        .info-value {
            color: #333;
            margin-top: 5px;
        }
        .success {
            color: #4CAF50;
            font-weight: bold;
        }
        .error {
            color: #f44336;
            font-weight: bold;
        }
        .warning {
            color: #ff9800;
            font-weight: bold;
        }
        pre {
            background: #f4f4f4;
            padding: 10px;
            border-radius: 4px;
            overflow-x: auto;
        }
        .test-section {
            margin-top: 30px;
            padding: 15px;
            background: #e3f2fd;
            border-radius: 4px;
            border-left: 4px solid #2196F3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 دیباگ وضعیت VIP</h1>
        
        <?php if (isset($_GET['success']) && $_GET['success'] == '1'): ?>
            <div style="background: #4CAF50; color: white; padding: 15px; border-radius: 4px; margin-bottom: 20px;">
                ✅ به‌روزرسانی با موفقیت انجام شد!
            </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['error'])): ?>
            <div style="background: #f44336; color: white; padding: 15px; border-radius: 4px; margin-bottom: 20px;">
                ❌ خطا: <?= htmlspecialchars($_GET['error']) ?>
            </div>
        <?php endif; ?>
        
        <div class="form-group">
            <form method="GET" action="">
                <label for="userid">شناسه کاربر (userid):</label>
                <input type="number" name="userid" id="userid" value="<?= $userid ?>" required>
                <button type="submit">بررسی</button>
            </form>
        </div>
        
        <?php if (!empty($debug_info)): ?>
            <div class="debug-section">
                <h2>📊 اطلاعات کاربر</h2>
                
                <?php if (isset($debug_info['error'])): ?>
                    <div class="info-item error">
                        <span class="info-label">خطا:</span>
                        <div class="info-value"><?= htmlspecialchars($debug_info['error']) ?></div>
                    </div>
                <?php elseif (isset($debug_info['user_found']) && $debug_info['user_found']): ?>
                    <div class="info-item">
                        <span class="info-label">نام کاربر:</span>
                        <div class="info-value"><?= htmlspecialchars($debug_info['user_data']['name']) ?></div>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">شناسه تلگرام (userid):</span>
                        <div class="info-value"><?= $debug_info['user_data']['userid'] ?></div>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">شناسه دیتابیس (id):</span>
                        <div class="info-value"><?= $debug_info['user_data']['id'] ?></div>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">vip_date (خام از دیتابیس):</span>
                        <div class="info-value"><?= htmlspecialchars($debug_info['vip_date_raw']) ?></div>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">vip_date (تبدیل به عدد):</span>
                        <div class="info-value"><?= $debug_info['vip_date_int'] ?></div>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">زمان فعلی (timestamp):</span>
                        <div class="info-value"><?= $debug_info['current_time'] ?></div>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">vip_date معتبر است؟</span>
                        <div class="info-value <?= $debug_info['vip_date_valid'] ? 'success' : 'error' ?>">
                            <?= $debug_info['vip_date_valid'] ? '✅ بله' : '❌ خیر' ?>
                        </div>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">نتیجه تابع is_vip():</span>
                        <div class="info-value <?= $debug_info['is_vip_result'] ? 'success' : 'error' ?>">
                            <?= $debug_info['is_vip_result'] ? '✅ VIP فعال است' : '❌ VIP غیرفعال است' ?>
                        </div>
                    </div>
                    
                    <?php if (isset($debug_info['vip_days_remaining']) && $debug_info['vip_days_remaining'] != 'N/A'): ?>
                        <div class="info-item">
                            <span class="info-label">روزهای باقیمانده:</span>
                            <div class="info-value"><?= $debug_info['vip_days_remaining'] ?> روز</div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="info-item">
                        <span class="info-label">تمام اطلاعات کاربر:</span>
                        <pre><?= print_r($debug_info['user_data'], true) ?></pre>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="test-section">
                <h2>🧪 تست به‌روزرسانی VIP</h2>
                <p>برای تست، می‌توانید مستقیماً از این صفحه VIP را فعال/غیرفعال کنید:</p>
                <form method="POST" action="test_update_vip.php">
                    <input type="hidden" name="userid" value="<?= $userid ?>">
                    <div class="form-group">
                        <label>وضعیت VIP:</label>
                        <select name="vip_status">
                            <option value="0">غیرفعال</option>
                            <option value="1" <?= isset($debug_info['is_vip_result']) && $debug_info['is_vip_result'] ? 'selected' : '' ?>>فعال</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>تعداد روزها (اگر فعال است):</label>
                        <input type="number" name="vip_days" value="30" min="1">
                    </div>
                    <button type="submit">تست به‌روزرسانی</button>
                </form>
            </div>
        <?php endif; ?>
        
        <div class="debug-section" style="margin-top: 30px;">
            <h2>📝 راهنمای دیباگ</h2>
            <ol>
                <li>شناسه کاربر (userid) را وارد کنید و روی "بررسی" کلیک کنید</li>
                <li>اطلاعات نمایش داده شده را بررسی کنید</li>
                <li>اگر vip_date معتبر نیست، از بخش "تست به‌روزرسانی" استفاده کنید</li>
                <li>لاگ‌های خطا را در فایل error_log سرور بررسی کنید</li>
                <li>برای بررسی لاگ‌ها، به مسیر <code>/home/isheresh/public_html/8/error_log</code> بروید</li>
            </ol>
        </div>
    </div>
</body>
</html>

