<?php
// اسکریپت به‌روزرسانی دیتابیس - تبدیل همه محتواها به رایگان
define('INDEX', true);
ob_start();
session_start();

// بررسی اینکه آیا کاربر لاگین است
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

require_once 'db.php';

$results = [];
$errors = [];

// بررسی اینکه آیا کاربر می‌خواهد به‌روزرسانی را انجام دهد
if (isset($_POST['update_database'])) {
    try {
        // 1. تبدیل همه محتواهای type='vip' به type='free'
        $sql1 = "UPDATE sp_files SET type='free' WHERE type='vip'";
        $stmt1 = $db->prepare($sql1);
        $stmt1->execute();
        $affected1 = $stmt1->rowCount();
        $results[] = "✅ $affected1 محتوا از نوع VIP به رایگان تبدیل شد.";
        
        // 2. به‌روزرسانی تنظیمات وب اپ - غیرفعال کردن حالت VIP
        $sql2 = "UPDATE sp_options SET value='0' WHERE name='enable_vip_mode'";
        $stmt2 = $db->prepare($sql2);
        $stmt2->execute();
        $affected2 = $stmt2->rowCount();
        if ($affected2 > 0) {
            $results[] = "✅ حالت VIP در تنظیمات وب اپ غیرفعال شد.";
        } else {
            // اگر تنظیم وجود نداشت، اضافه می‌کنیم
            $sql2_insert = "INSERT INTO sp_options (name, value) VALUES ('enable_vip_mode', '0') ON DUPLICATE KEY UPDATE value='0'";
            $stmt2_insert = $db->prepare($sql2_insert);
            $stmt2_insert->execute();
            $results[] = "✅ تنظیم enable_vip_mode اضافه و غیرفعال شد.";
        }
        
        // 3. بررسی و نمایش آمار
        $sql3 = "SELECT COUNT(*) as total FROM sp_files WHERE type='free'";
        $stmt3 = $db->prepare($sql3);
        $stmt3->execute();
        $free_count = $stmt3->fetch(PDO::FETCH_ASSOC)['total'];
        
        $sql4 = "SELECT COUNT(*) as total FROM sp_files WHERE type='vip'";
        $stmt4 = $db->prepare($sql4);
        $stmt4->execute();
        $vip_count = $stmt4->fetch(PDO::FETCH_ASSOC)['total'];
        
        $results[] = "📊 آمار: $free_count محتوای رایگان، $vip_count محتوای VIP";
        
        $success = true;
    } catch (PDOException $e) {
        $errors[] = "❌ خطا: " . $e->getMessage();
        $success = false;
    }
}

// دریافت آمار فعلی
$stats = [];
try {
    $sql_free = "SELECT COUNT(*) as count FROM sp_files WHERE type='free'";
    $stmt_free = $db->prepare($sql_free);
    $stmt_free->execute();
    $stats['free'] = $stmt_free->fetch(PDO::FETCH_ASSOC)['count'];
    
    $sql_vip = "SELECT COUNT(*) as count FROM sp_files WHERE type='vip'";
    $stmt_vip = $db->prepare($sql_vip);
    $stmt_vip->execute();
    $stats['vip'] = $stmt_vip->fetch(PDO::FETCH_ASSOC)['count'];
    
    $sql_total = "SELECT COUNT(*) as count FROM sp_files";
    $stmt_total = $db->prepare($sql_total);
    $stmt_total->execute();
    $stats['total'] = $stmt_total->fetch(PDO::FETCH_ASSOC)['count'];
} catch (PDOException $e) {
    $errors[] = "خطا در دریافت آمار: " . $e->getMessage();
}

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>به‌روزرسانی دیتابیس - تبدیل به رایگان</title>
    <style>
        body {
            font-family: Tahoma, Arial, sans-serif;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            border-bottom: 2px solid #4CAF50;
            padding-bottom: 10px;
        }
        .stats {
            background: #e3f2fd;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            border-left: 4px solid #2196F3;
        }
        .stat-item {
            margin: 10px 0;
            font-size: 16px;
        }
        .stat-label {
            font-weight: bold;
            color: #666;
        }
        .stat-value {
            color: #333;
            font-size: 18px;
        }
        .warning {
            background: #fff3cd;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            border-left: 4px solid #ffc107;
        }
        .warning h3 {
            margin-top: 0;
            color: #856404;
        }
        .result {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .success {
            background: #d4edda;
            border-left: 4px solid #28a745;
            color: #155724;
        }
        .error {
            background: #f8d7da;
            border-left: 4px solid #dc3545;
            color: #721c24;
        }
        button {
            background: #4CAF50;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }
        button:hover {
            background: #45a049;
        }
        .info {
            background: #d1ecf1;
            padding: 15px;
            border-radius: 4px;
            margin-top: 20px;
            border-left: 4px solid #17a2b8;
        }
        ul {
            margin: 10px 0;
            padding-right: 20px;
        }
        li {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔄 به‌روزرسانی دیتابیس - تبدیل به رایگان</h1>
        
        <?php if (!empty($results)): ?>
            <div class="result success">
                <h3>✅ به‌روزرسانی با موفقیت انجام شد:</h3>
                <ul>
                    <?php foreach ($results as $result): ?>
                        <li><?= htmlspecialchars($result) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
            <div class="result error">
                <h3>❌ خطاها:</h3>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <div class="stats">
            <h2>📊 آمار فعلی دیتابیس</h2>
            <div class="stat-item">
                <span class="stat-label">کل محتواها:</span>
                <span class="stat-value"><?= number_format($stats['total'] ?? 0) ?></span>
            </div>
            <div class="stat-item">
                <span class="stat-label">محتواهای رایگان:</span>
                <span class="stat-value" style="color: #4CAF50;"><?= number_format($stats['free'] ?? 0) ?></span>
            </div>
            <div class="stat-item">
                <span class="stat-label">محتواهای VIP:</span>
                <span class="stat-value" style="color: #f44336;"><?= number_format($stats['vip'] ?? 0) ?></span>
            </div>
        </div>
        
        <?php if (($stats['vip'] ?? 0) > 0): ?>
            <div class="warning">
                <h3>⚠️ هشدار</h3>
                <p>در حال حاضر <strong><?= number_format($stats['vip'] ?? 0) ?></strong> محتوای VIP در دیتابیس وجود دارد.</p>
                <p>با کلیک روی دکمه زیر، همه محتواهای VIP به رایگان تبدیل می‌شوند.</p>
            </div>
            
            <form method="POST" action="" onsubmit="return confirm('آیا مطمئن هستید که می‌خواهید همه محتواهای VIP را به رایگان تبدیل کنید؟');">
                <button type="submit" name="update_database">🔄 تبدیل همه محتواهای VIP به رایگان</button>
            </form>
        <?php else: ?>
            <div class="result success">
                <h3>✅ همه محتواها رایگان هستند!</h3>
                <p>هیچ محتوای VIP در دیتابیس وجود ندارد. همه چیز آماده است.</p>
            </div>
        <?php endif; ?>
        
        <div class="info">
            <h3>ℹ️ اطلاعات</h3>
            <p>این اسکریپت:</p>
            <ul>
                <li>همه محتواهای <code>type='vip'</code> را به <code>type='free'</code> تبدیل می‌کند</li>
                <li>تنظیم <code>enable_vip_mode</code> را در جدول <code>sp_options</code> غیرفعال می‌کند</li>
                <li>آمار به‌روزرسانی شده را نمایش می‌دهد</li>
            </ul>
            <p><strong>نکته:</strong> این عملیات قابل بازگشت نیست. قبل از اجرا، از دیتابیس خود بکاپ بگیرید.</p>
        </div>
    </div>
</body>
</html>

