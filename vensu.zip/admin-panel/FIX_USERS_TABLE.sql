-- ============================================================
-- فایل اصلاح و بررسی جدول sp_users
-- ============================================================
-- این فایل برای اطمینان از صحت ساختار جدول sp_users است
-- ============================================================

-- بررسی وجود جدول
-- اگر جدول وجود ندارد، آن را ایجاد می‌کند
CREATE TABLE IF NOT EXISTS `sp_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL COMMENT 'شناسه تلگرام',
  `name` varchar(255) NOT NULL COMMENT 'نام',
  `username` varchar(50) DEFAULT NULL COMMENT 'یوزرنیم',
  `phone` varchar(20) DEFAULT NULL COMMENT 'شماره تلفن (پشتیبانی از شماره‌های بین‌المللی)',
  `vip_date` varchar(30) NOT NULL DEFAULT '0' COMMENT 'تاریخ انقضای VIP',
  `vip_plan` varchar(50) NOT NULL DEFAULT '0' COMMENT 'نام پلن VIP',
  `vip_refid` int(11) NOT NULL DEFAULT 0 COMMENT 'کد تراکنش VIP',
  `verified` int(11) NOT NULL DEFAULT 0 COMMENT 'وضعیت تایید شماره: 1=تایید شده، 0=تایید نشده',
  `channels_joined` int(11) NOT NULL DEFAULT 0 COMMENT 'وضعیت عضویت در کانال‌ها: 1=عضو شده، 0=عضو نشده',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userid` (`userid`),
  KEY `idx_userid` (`userid`),
  KEY `idx_verified` (`verified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- بررسی و اصلاح فیلدها در صورت نیاز
-- ============================================================

-- اطمینان از اینکه id به عنوان PRIMARY KEY و AUTO_INCREMENT است
ALTER TABLE `sp_users` 
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

-- اطمینان از اینکه userid به عنوان UNIQUE KEY است
ALTER TABLE `sp_users` 
  ADD UNIQUE KEY IF NOT EXISTS `userid` (`userid`);

-- اضافه کردن Index برای بهبود عملکرد
ALTER TABLE `sp_users` 
  ADD INDEX IF NOT EXISTS `idx_userid` (`userid`);

ALTER TABLE `sp_users` 
  ADD INDEX IF NOT EXISTS `idx_verified` (`verified`);

-- ============================================================
-- بررسی داده‌های موجود
-- ============================================================

-- نمایش ساختار جدول
-- DESCRIBE sp_users;

-- نمایش تعداد کاربران
-- SELECT COUNT(*) as total_users FROM sp_users;

-- نمایش نمونه کاربران
-- SELECT id, userid, name, verified, vip_date FROM sp_users LIMIT 10;

