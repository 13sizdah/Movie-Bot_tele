<?php
if (!defined('INDEX')) {
    die('403-Forbidden Access');
}
if (isset($_GET['vip_plus'])) {
    $userid = intval($_GET['vip_plus']);
    user_info($userid);
?>
    <div class="overflow-auto h-screen pb-24 pt-2 pr-2 pl-2 md:pt-0 md:pr-0 md:pl-0">
        <div class="flex flex-col flex-wrap sm:flex-row ">
            <div class="container mx-auto px-4 sm:px-8 max-w-8xl">
                <div class="py-2">
                    <div class="flex flex-row mb-1 sm:mb-0 justify-between w-full">
                        <h2 class="text-2xl leading-tight">
                            افزایش روز های اشتراک ویژه
                        </h2>
                    </div>
                    <div class="-mx-4 sm:-mx-8 px-4 sm:px-8 py-4 overflow-x-auto">
                        <div class="inline-block min-w-full shadow rounded-lg overflow-hidden">
                            <table class="min-w-full leading-normal">
                                <thead>
                                    <tr>
                                        <th scope="col" class="px-5 py-3 bg-white  border-b border-gray-200 text-gray-800  text-right text-sm uppercase font-normal">
                                            نام کاربر
                                        </th>
                                        <th scope="col" class="px-5 py-3 bg-white  border-b border-gray-200 text-gray-800  text-right text-sm uppercase font-normal">
                                            شناسه عددی
                                        </th>
                                        <th scope="col" class="px-5 py-3 bg-white  border-b border-gray-200 text-gray-800  text-right text-sm uppercase font-normal">
                                            نام کاربری
                                        </th>
                                        <th scope="col" class="px-5 py-3 bg-white  border-b border-gray-200 text-gray-800  text-right text-sm uppercase font-normal">
                                            شماره تلفن
                                        </th>
                                        <th scope="col" class="px-5 py-3 bg-white  border-b border-gray-200 text-gray-800  text-right text-sm uppercase font-normal">
                                            باقیمانده از اشتراک
                                        </th>

                                    </tr>
                                </thead>
                                <tbody>

                                    <tr>
                                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                            <p class="text-gray-900 whitespace-no-wrap">
                                                <?= $name; ?>
                                            </p>
                                        </td>
                                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                            <p class="text-gray-900 whitespace-no-wrap">
                                                <?= $userid; ?>
                                            </p>
                                        </td>
                                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                            <p class="text-gray-900 whitespace-no-wrap">
                                                <?php
                                                if (isset($username) && !empty($username)) {
                                                    echo "<a href='https://t.me/$username'>$username</a>";
                                                } else { ?>
                                                    <span class="relative inline-block px-3 py-1 text-red-900 leading-tight">
                                                        <span aria-hidden="true" class="absolute inset-0 bg-red-200 opacity-50 rounded-full">
                                                        </span>
                                                        <span class="relative">
                                                            ندارد
                                                        </span>
                                                    </span>
                                                <?php } ?>
                                            </p>
                                        </td>
                                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                            <p class="text-gray-900 whitespace-no-wrap">
                                                <?php
                                                if (isset($phone) && !empty($phone) && $phone != 0) {
                                                    echo $phone;
                                                } else { ?>
                                                    <span class="relative inline-block px-3 py-1 text-red-900 leading-tight">
                                                        <span aria-hidden="true" class="absolute inset-0 bg-red-200 opacity-50 rounded-full">
                                                        </span>
                                                        <span class="relative">
                                                            تایید نشده
                                                        </span>
                                                    </span>
                                                <?php } ?>
                                            </p>
                                        </td>
                                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                            <p class="text-gray-900 whitespace-no-wrap">
                                                <?php if (is_vip($userid)) {
                                                    echo $vip_days . ' روز';
                                                } else {
                                                    echo '-';
                                                } ?>
                                            </p>
                                        </td>

                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="flex flex-col  flex-wrap sm:flex-row ">
            <div class="container mx-auto px-4 sm:px-8 max-w-8xl">


                <div class="bg-white rounded-lg shadow min-w-full sm:overflow-hidden mt-5">
                    <div class="px-4 py-8 sm:px-10">
                        <div class="relative mt-6">
                            <div class="absolute inset-0 flex items-center">
                                <div class="w-full border-t border-gray-300">
                                </div>
                            </div>
                            <div class="relative flex justify-center text-sm leading-5">
                                <span class="px-2 text-gray-500 bg-white">
                                    تعداد روز هایی که می خواهید به اشتراک کاربر اضافه شود را وارد کنید و سپس دکمه ثبت را
                                    بزنید
                                </span>
                            </div>
                        </div>
                        <form method="POST" action="">
                            <div class="mt-6">
                                <div class="w-full space-y-10">
                                    <div class="w-full">
                                        <div class=" relative ">
                                            <label for="name" class="text-gray-700">
                                                چند روز اضافه شود؟
                                            </label>
                                            <input type="text" name="days" class=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" placeholder="برای مثال : 30" />
                                        </div>
                                    </div>

                                    <div>
                                        <span class="block w-full rounded-md shadow-sm">
                                            <button type="submit" name="vip_days" class="py-2 px-4  bg-indigo-600 hover:bg-indigo-700 focus:ring-indigo-500 focus:ring-offset-indigo-200 text-white w-full transition ease-in duration-200 text-center text-base font-semibold shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2  rounded-lg ">
                                                ثبت
                                            </button>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php }
if (isset($_POST['vip_days'])) {
    // دریافت userid از GET (که قبلاً در vip_plus تنظیم شده)
    $userid = isset($_GET['vip_plus']) ? intval($_GET['vip_plus']) : 0;
    $days = isset($_POST['days']) ? intval($_POST['days']) : 0;
    
    if ($userid <= 0) {
        ?>
        <script type="text/javascript">
            alert('خطا: شناسه کاربر نامعتبر است');
            window.location = "users.php?vip_add_error";
        </script>
        <?php
        exit;
    }
    
    if ($days <= 0) {
        ?>
        <script type="text/javascript">
            alert('خطا: تعداد روز باید بیشتر از صفر باشد');
            window.location = "users.php?vip_add_error";
        </script>
        <?php
        exit;
    }
    
    $result = add_vip_days($userid, $days);
    if ($result) {
    ?>
        <script type="text/javascript">
            window.location = "users.php?vip_added";
        </script>
    <?php } else { ?>
        <script type="text/javascript">
            window.location = "users.php?vip_add_error";
        </script>
<?php }
} ?>

<?php if (isset($_GET['vip_added'])) { ?>
    <div id="alert1" class="my-3  block  text-left text-white bg-green-500 h-12 flex items-center justify-center p-4 rounded-md relative" role="alert">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="flex-shrink-0 w-6 h-6 mx-2 stroke-current">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9">
            </path>
        </svg>
        روز های اشتراک با موفقیت اضافه شد.
        <button onclick="closeAlert()" class="absolute bg-transparent text-2xl font-semibold leading-none right-0 top-0 mt-3 mr-6 outline-none focus:outline-none">
            <span>×</span>
        </button>
    </div>
<?php } ?>

<?php if (isset($_GET['vip_add_error'])) { ?>
    <div id="alert1" class="my-3  block  text-left text-white bg-red-500 h-12 flex items-center justify-center p-4 rounded-md relative" role="alert">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="flex-shrink-0 w-6 h-6 mx-2 stroke-current">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9">
            </path>
        </svg>
        مشکلی در اضافه کردن روز های اشتراک بوجود آمده است
        <button onclick="closeAlert()" class="absolute bg-transparent text-2xl font-semibold leading-none right-0 top-0 mt-3 mr-6 outline-none focus:outline-none">
            <span>×</span>
        </button>
    </div>
<?php } ?>


<!-- delete user -->


<?php if (isset($_GET['del_user'])) {
    if (delete_user()) { ?>
        <script type="text/javascript">
            window.location = "users.php?user_del";
        </script>
    <?php } else { ?>
        <script type="text/javascript">
            window.location = "users.php?user_del_error";
        </script>
<?php
    }
} ?>

<?php if (isset($_GET['user_del'])) { ?>
    <div id="alert1" class="my-3  block  text-left text-white bg-green-500 h-12 flex items-center justify-center p-4 rounded-md relative" role="alert">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="flex-shrink-0 w-6 h-6 mx-2 stroke-current">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9">
            </path>
        </svg>
        کاربر با موفقیت حذف شد
        <button onclick="closeAlert()" class="absolute bg-transparent text-2xl font-semibold leading-none right-0 top-0 mt-3 mr-6 outline-none focus:outline-none">
            <span>×</span>
        </button>
    </div>
<?php } ?>

<?php if (isset($_GET['user_del_error'])) { ?>
    <div id="alert1" class="my-3  block  text-left text-white bg-red-500 h-12 flex items-center justify-center p-4 rounded-md relative" role="alert">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="flex-shrink-0 w-6 h-6 mx-2 stroke-current">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9">
            </path>
        </svg>
        مشکلی در حذف کاربر بوجود آمده است
        <button onclick="closeAlert()" class="absolute bg-transparent text-2xl font-semibold leading-none right-0 top-0 mt-3 mr-6 outline-none focus:outline-none">
            <span>×</span>
        </button>
    </div>
<?php } ?>

<!-- ویرایش کاربر -->
<?php if (isset($_GET['edit_user'])) {
    // اگر edit_by_userid=1 باشد، از userid استفاده می‌کنیم، در غیر این صورت از id
    $edit_by_userid = isset($_GET['edit_by_userid']) && $_GET['edit_by_userid'] == '1';
    
    if ($edit_by_userid) {
        // استفاده از userid (شناسه تلگرام)
        $userid = intval($_GET['edit_user']);
        if ($userid <= 0) {
            ?>
            <script type="text/javascript">
                alert('خطا: شناسه کاربر نامعتبر است');
                window.location = "users.php";
            </script>
            <?php
            exit;
        }
        // دریافت اطلاعات کاربر بر اساس userid
        $edit_result = edit_user_info_by_userid($userid);
        $user_id_for_form = $userid; // برای استفاده در فرم
        $use_userid = true; // فلگ برای استفاده از userid
    } else {
        // استفاده از id (شناسه دیتابیس)
        $user_id = intval($_GET['edit_user']);
        if ($user_id <= 0) {
            ?>
            <script type="text/javascript">
                alert('خطا: شناسه کاربر نامعتبر است');
                window.location = "users.php";
            </script>
            <?php
            exit;
        }
        // دریافت اطلاعات کاربر بر اساس id
        $edit_result = edit_user_info($user_id);
        $user_id_for_form = $user_id; // برای استفاده در فرم
        $use_userid = false; // فلگ برای استفاده از id
    }
    
    // بررسی اینکه اطلاعات کاربر با موفقیت دریافت شد
    if (!$edit_result || !isset($edit_user_name)) {
        ?>
        <script type="text/javascript">
            alert('خطا: کاربر یافت نشد');
            window.location = "users.php";
        </script>
        <?php
        exit;
    }
?>
    <div class="overflow-auto h-screen pb-24 pt-2 pr-2 pl-2 md:pt-0 md:pr-0 md:pl-0">
        <div class="flex flex-col flex-wrap sm:flex-row ">
            <div class="container mx-auto px-4 sm:px-8 max-w-8xl">
                <div class="py-2">
                    <div class="flex flex-row mb-1 sm:mb-0 justify-between w-full">
                        <h2 class="text-2xl leading-tight">
                            ویرایش کاربر
                        </h2>
                        <a href="users.php" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                            بازگشت
                        </a>
                    </div>
                    <div class="-mx-4 sm:-mx-8 px-4 sm:px-8 py-4 overflow-x-auto">
                        <div class="inline-block min-w-full shadow rounded-lg overflow-hidden">
                            <table class="min-w-full leading-normal">
                                <thead>
                                    <tr>
                                        <th scope="col" class="px-5 py-3 bg-white  border-b border-gray-200 text-gray-800  text-right text-sm uppercase font-normal">
                                            نام کاربر
                                        </th>
                                        <th scope="col" class="px-5 py-3 bg-white  border-b border-gray-200 text-gray-800  text-right text-sm uppercase font-normal">
                                            شناسه عددی
                                        </th>
                                        <th scope="col" class="px-5 py-3 bg-white  border-b border-gray-200 text-gray-800  text-right text-sm uppercase font-normal">
                                            نام کاربری
                                        </th>
                                        <th scope="col" class="px-5 py-3 bg-white  border-b border-gray-200 text-gray-800  text-right text-sm uppercase font-normal">
                                            شماره تلفن
                                        </th>
                                        <th scope="col" class="px-5 py-3 bg-white  border-b border-gray-200 text-gray-800  text-right text-sm uppercase font-normal">
                                            وضعیت تایید
                                        </th>
                                        <th scope="col" class="px-5 py-3 bg-white  border-b border-gray-200 text-gray-800  text-right text-sm uppercase font-normal">
                                            وضعیت VIP
                                        </th>
                                        <th scope="col" class="px-5 py-3 bg-white  border-b border-gray-200 text-gray-800  text-right text-sm uppercase font-normal">
                                            باقیمانده از اشتراک
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                            <p class="text-gray-900 whitespace-no-wrap">
                                                <?= htmlspecialchars($edit_user_name); ?>
                                            </p>
                                        </td>
                                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                            <p class="text-gray-900 whitespace-no-wrap">
                                                <?= $edit_user_userid; ?>
                                            </p>
                                        </td>
                                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                            <p class="text-gray-900 whitespace-no-wrap">
                                                <?php
                                                if (isset($edit_user_username) && !empty($edit_user_username)) {
                                                    echo htmlspecialchars($edit_user_username);
                                                } else { ?>
                                                    <span class="relative inline-block px-3 py-1 text-red-900 leading-tight">
                                                        <span aria-hidden="true" class="absolute inset-0 bg-red-200 opacity-50 rounded-full">
                                                        </span>
                                                        <span class="relative">
                                                            ندارد
                                                        </span>
                                                    </span>
                                                <?php } ?>
                                            </p>
                                        </td>
                                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                            <p class="text-gray-900 whitespace-no-wrap">
                                                <?php
                                                if (isset($edit_user_phone) && !empty($edit_user_phone) && $edit_user_phone != 0) {
                                                    echo htmlspecialchars($edit_user_phone);
                                                } else { ?>
                                                    <span class="relative inline-block px-3 py-1 text-red-900 leading-tight">
                                                        <span aria-hidden="true" class="absolute inset-0 bg-red-200 opacity-50 rounded-full">
                                                        </span>
                                                        <span class="relative">
                                                            تایید نشده
                                                        </span>
                                                    </span>
                                                <?php } ?>
                                            </p>
                                        </td>
                                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                            <p class="text-gray-900 whitespace-no-wrap">
                                                <?php if ($edit_user_verified == 1) { ?>
                                                    <span class="relative inline-block px-3 py-1 text-green-900 leading-tight">
                                                        <span aria-hidden="true" class="absolute inset-0 bg-green-200 opacity-50 rounded-full">
                                                        </span>
                                                        <span class="relative">
                                                            تایید شده
                                                        </span>
                                                    </span>
                                                <?php } else { ?>
                                                    <span class="relative inline-block px-3 py-1 text-red-900 leading-tight">
                                                        <span aria-hidden="true" class="absolute inset-0 bg-red-200 opacity-50 rounded-full">
                                                        </span>
                                                        <span class="relative">
                                                            تایید نشده
                                                        </span>
                                                    </span>
                                                <?php } ?>
                                            </p>
                                        </td>
                                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                            <p class="text-gray-900 whitespace-no-wrap">
                                                <?php if (is_vip($edit_user_userid)) { ?>
                                                    <span class="relative inline-block px-3 py-1 text-green-900 leading-tight">
                                                        <span aria-hidden="true" class="absolute inset-0 bg-green-200 opacity-50 rounded-full">
                                                        </span>
                                                        <span class="relative">
                                                            فعال
                                                        </span>
                                                    </span>
                                                <?php } else { ?>
                                                    <span class="relative inline-block px-3 py-1 text-yellow-900 leading-tight">
                                                        <span aria-hidden="true" class="absolute inset-0 bg-yellow-200 opacity-50 rounded-full">
                                                        </span>
                                                        <span class="relative">
                                                            غیرفعال
                                                        </span>
                                                    </span>
                                                <?php } ?>
                                            </p>
                                        </td>
                                        <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                            <p class="text-gray-900 whitespace-no-wrap">
                                                <?php if (is_vip($edit_user_userid)) {
                                                    echo $vip_days . ' روز';
                                                } else {
                                                    echo 'اشتراک ندارد';
                                                } ?>
                                            </p>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="flex flex-col  flex-wrap sm:flex-row ">
            <div class="container mx-auto px-4 sm:px-8 max-w-8xl">
                <div class="bg-white rounded-lg shadow min-w-full sm:overflow-hidden mt-5">
                    <div class="px-4 py-8 sm:px-10">
                        <div class="relative mt-6">
                            <div class="absolute inset-0 flex items-center">
                                <div class="w-full border-t border-gray-300">
                                </div>
                            </div>
                            <div class="relative flex justify-center text-sm leading-5">
                                <span class="px-2 text-gray-500 bg-white">
                                    اطلاعات کاربر را ویرایش کنید و سپس دکمه ثبت را بزنید
                                </span>
                            </div>
                        </div>
                        <?php 
                        // اطمینان از اینکه user_id_for_form تعریف شده است
                        if (!isset($user_id_for_form) || $user_id_for_form <= 0) {
                            // تلاش برای دریافت از GET
                            $user_id_for_form = isset($_GET['edit_user']) ? intval($_GET['edit_user']) : 0;
                        }
                        // اطمینان از اینکه use_userid تعریف شده است
                        if (!isset($use_userid)) {
                            // تلاش برای دریافت از GET
                            $use_userid = isset($_GET['edit_by_userid']) && $_GET['edit_by_userid'] == '1';
                        }
                        ?>
                        <form method="POST" action="users.php<?= isset($user_id_for_form) && $user_id_for_form > 0 ? '?edit_user=' . $user_id_for_form . ($use_userid ? '&edit_by_userid=1' : '') : '' ?>">
                            <?php if ($use_userid): ?>
                                <!-- استفاده از userid -->
                                <input type="hidden" name="userid" value="<?= isset($user_id_for_form) && $user_id_for_form > 0 ? intval($user_id_for_form) : 0 ?>">
                                <input type="hidden" name="use_userid" value="1">
                            <?php else: ?>
                                <!-- استفاده از id -->
                                <input type="hidden" name="user_id" value="<?= isset($user_id_for_form) && $user_id_for_form > 0 ? intval($user_id_for_form) : 0 ?>">
                            <?php endif; ?>
                            <?php if (!isset($user_id_for_form) || $user_id_for_form <= 0): ?>
                                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                                    خطا: شناسه کاربر نامعتبر است. لطفاً دوباره از صفحه کاربران، دکمه ویرایش را بزنید.
                                </div>
                            <?php endif; ?>
                            <div class="mt-6">
                                <div class="w-full space-y-10">
                                    <div class="w-full">
                                        <div class=" relative ">
                                            <label for="user_name" class="text-gray-700">
                                                نام کاربر
                                            </label>
                                            <input type="text" name="user_name" id="user_name" value="<?= htmlspecialchars($edit_user_name) ?>" class=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" />
                                        </div>
                                    </div>
                                    
                                    <div class="w-full">
                                        <div class=" relative ">
                                            <label for="user_phone" class="text-gray-700">
                                                شماره تلفن
                                            </label>
                                            <input type="text" name="user_phone" id="user_phone" value="<?= htmlspecialchars($edit_user_phone) ?>" class=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" />
                                        </div>
                                    </div>
                                    
                                    <div class="w-full">
                                        <div class=" relative ">
                                            <label for="user_verified" class="text-gray-700">
                                                وضعیت تایید شماره تلفن
                                            </label>
                                            <select name="user_verified" id="user_verified" class=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent">
                                                <option value="0" <?= $edit_user_verified == 0 ? 'selected' : '' ?>>تایید نشده</option>
                                                <option value="1" <?= $edit_user_verified == 1 ? 'selected' : '' ?>>تایید شده</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="w-full">
                                        <div class=" relative ">
                                            <label for="vip_status" class="text-gray-700">
                                                وضعیت اشتراک VIP
                                            </label>
                                            <select name="vip_status" id="vip_status" class=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" onchange="toggleVipDays()">
                                                <option value="0" <?= !is_vip($edit_user_userid) ? 'selected' : '' ?>>غیرفعال</option>
                                                <option value="1" <?= is_vip($edit_user_userid) ? 'selected' : '' ?>>فعال</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="w-full" id="vip_days_container" style="<?= !is_vip($edit_user_userid) ? 'display: none;' : '' ?>">
                                        <div class=" relative ">
                                            <label for="vip_days" class="text-gray-700">
                                                تعداد روزهای باقیمانده از اشتراک (برای فعال کردن VIP، تعداد روز را وارد کنید)
                                            </label>
                                            <input type="number" name="vip_days" id="vip_days" value="<?= is_vip($edit_user_userid) ? $vip_days : '0' ?>" min="0" class=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent" placeholder="برای مثال: 30" />
                                        </div>
                                    </div>
                                    <!-- فیلد مخفی برای vip_days در صورت غیرفعال بودن VIP -->
                                    <input type="hidden" name="vip_days_hidden" id="vip_days_hidden" value="0">

                                    <div>
                                        <span class="block w-full rounded-md shadow-sm">
                                            <button type="submit" name="update_user" class="py-2 px-4  bg-indigo-600 hover:bg-indigo-700 focus:ring-indigo-500 focus:ring-offset-indigo-200 text-white w-full transition ease-in duration-200 text-center text-base font-semibold shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2  rounded-lg ">
                                                ثبت تغییرات
                                            </button>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function toggleVipDays() {
        var vipStatus = document.getElementById('vip_status').value;
        var vipDaysContainer = document.getElementById('vip_days_container');
        var vipDaysInput = document.getElementById('vip_days');
        var vipDaysHidden = document.getElementById('vip_days_hidden');
        
        if (vipStatus == '1') {
            vipDaysContainer.style.display = 'block';
            if (vipDaysInput) {
                // اگر مقدار خالی است یا 0 است، 30 روز پیش‌فرض بگذار
                if (!vipDaysInput.value || vipDaysInput.value == '0' || vipDaysInput.value == '') {
                    vipDaysInput.value = '30';
                }
            }
            if (vipDaysHidden) {
                vipDaysHidden.value = vipDaysInput ? vipDaysInput.value : '30';
            }
        } else {
            vipDaysContainer.style.display = 'none';
            if (vipDaysInput) {
                vipDaysInput.value = '0';
            }
            if (vipDaysHidden) {
                vipDaysHidden.value = '0';
            }
        }
    }
    
    // اطمینان از اینکه قبل از ارسال فرم، مقدار vip_days تنظیم شده است
    document.addEventListener('DOMContentLoaded', function() {
        var form = document.querySelector('form[method="POST"]');
        if (form) {
            form.addEventListener('submit', function(e) {
                var vipStatus = document.getElementById('vip_status');
                var vipDaysInput = document.getElementById('vip_days');
                
                if (vipStatus && vipStatus.value == '1') {
                    // اگر VIP فعال است و مقدار vip_days خالی یا 0 است، 30 روز پیش‌فرض بگذار
                    if (vipDaysInput && (!vipDaysInput.value || vipDaysInput.value == '0' || vipDaysInput.value == '')) {
                        vipDaysInput.value = '30';
                    }
                }
            });
        }
    });
    </script>

    <?php }
if (isset($_POST['update_user'])) {
    // لاگ کردن تمام POST برای دیباگ
    error_log("DEBUG update_user - POST: " . print_r($_POST, true));
    error_log("DEBUG update_user - GET: " . print_r($_GET, true));
    
    // بررسی اینکه آیا از userid استفاده می‌کنیم یا id
    $use_userid = isset($_POST['use_userid']) && $_POST['use_userid'] == '1';
    // اگر در POST نبود، از GET بگیر
    if (!$use_userid && isset($_GET['edit_by_userid']) && $_GET['edit_by_userid'] == '1') {
        $use_userid = true;
    }
    
    if ($use_userid) {
        // استفاده از userid (شناسه تلگرام)
        $userid = isset($_POST['userid']) ? intval($_POST['userid']) : 0;
        
        // اگر userid در POST نبود، از GET بگیر
        if ($userid <= 0 && isset($_GET['edit_user'])) {
            $userid = intval($_GET['edit_user']);
        }
        
        error_log("DEBUG update_user - Using userid: " . $userid);
        
        if ($userid <= 0) {
            error_log("Error in update_user: Invalid userid. POST: " . print_r($_POST, true) . " GET: " . print_r($_GET, true));
            ?>
            <script type="text/javascript">
                alert('خطا: شناسه کاربر نامعتبر است (userid: <?= $userid ?>)');
                console.log('POST data:', <?= json_encode($_POST) ?>);
                console.log('GET data:', <?= json_encode($_GET) ?>);
                window.location = "users.php?user_update_error";
            </script>
            <?php
            exit;
        }
        
        // استفاده مستقیم از userid برای به‌روزرسانی (بدون نیاز به تبدیل به id)
        // نیازی به تبدیل نیست - مستقیماً با userid به‌روزرسانی می‌کنیم
    } else {
        // استفاده از id (شناسه دیتابیس)
        $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
        
        // اگر user_id در POST نبود، از GET بگیر
        if ($user_id <= 0 && isset($_GET['edit_user'])) {
            $user_id = intval($_GET['edit_user']);
        }
        
        error_log("DEBUG update_user - Using id: " . $user_id);
        
        if ($user_id <= 0) {
            error_log("Error in update_user: Invalid user_id. POST: " . print_r($_POST, true) . " GET: " . print_r($_GET, true));
            ?>
            <script type="text/javascript">
                alert('خطا: شناسه کاربر نامعتبر است (id: <?= $user_id ?>)');
                console.log('POST data:', <?= json_encode($_POST) ?>);
                console.log('GET data:', <?= json_encode($_GET) ?>);
                window.location = "users.php?user_update_error";
            </script>
            <?php
            exit;
        }
        
        // تبدیل id به userid برای استفاده در تابع update_user_by_userid
        $userid = get_userid_by_id($user_id);
        if ($userid <= 0) {
            error_log("Error in update_user: Could not get userid from id: " . $user_id);
            ?>
            <script type="text/javascript">
                alert('خطا: کاربر یافت نشد');
                window.location = "users.php?user_update_error";
            </script>
            <?php
            exit;
        }
        $use_userid = true; // استفاده از userid
    }
    
    $user_name = isset($_POST['user_name']) ? trim($_POST['user_name']) : '';
    $user_phone = isset($_POST['user_phone']) ? trim($_POST['user_phone']) : '';
    $user_verified = isset($_POST['user_verified']) ? intval($_POST['user_verified']) : 0;
    $vip_status = isset($_POST['vip_status']) ? intval($_POST['vip_status']) : 0;
    
    // لاگ کردن مقادیر دریافت شده
    error_log("DEBUG update_user - vip_status from POST: " . (isset($_POST['vip_status']) ? $_POST['vip_status'] : 'not set'));
    error_log("DEBUG update_user - vip_days from POST: " . (isset($_POST['vip_days']) ? $_POST['vip_days'] : 'not set'));
    error_log("DEBUG update_user - vip_status (intval): " . $vip_status);
    
    // دریافت vip_days - اگر vip_status = 0 باشد، vip_days = 0
    if ($vip_status == 1) {
        // اگر vip_days در POST نبود یا خالی بود، از hidden field بگیر
        if (isset($_POST['vip_days']) && !empty($_POST['vip_days'])) {
            $vip_days = intval($_POST['vip_days']);
        } elseif (isset($_POST['vip_days_hidden']) && !empty($_POST['vip_days_hidden'])) {
            $vip_days = intval($_POST['vip_days_hidden']);
        } else {
            $vip_days = 0;
        }
        
        // اگر vip_days = 0 و vip_status = 1، 30 روز پیش‌فرض
        if ($vip_days <= 0) {
            $vip_days = 30;
        }
    } else {
        $vip_days = 0;
    }
    
    error_log("DEBUG update_user - Final vip_status: " . $vip_status . " | vip_days: " . $vip_days);
    
    // بررسی اینکه نام کاربر خالی نباشد
    if (empty($user_name)) {
        ?>
        <script type="text/javascript">
            alert('خطا: نام کاربر نمی‌تواند خالی باشد');
            window.location = "users.php?edit_user=<?= $userid ?>&edit_by_userid=1&user_update_error";
        </script>
        <?php
        exit;
    }
    
    // استفاده از تابع update_user_by_userid که مستقیماً با userid کار می‌کند
    error_log("DEBUG update_user - About to call update_user_by_userid with: userid=" . $userid . ", vip_status=" . $vip_status . ", vip_days=" . $vip_days);
    $result = update_user_by_userid($userid, $user_name, $user_phone, $user_verified, $vip_status, $vip_days);
    error_log("DEBUG update_user - Result from update_user_by_userid: " . ($result ? 'true' : 'false'));
    
    if ($result) {
        // بررسی مجدد برای اطمینان از ذخیره شدن
        try {
            $sql_check = "SELECT vip_date FROM sp_users WHERE userid=:userid LIMIT 1";
            $stmt_check = $db->prepare($sql_check);
            $stmt_check->bindValue(':userid', $userid, PDO::PARAM_INT);
            $stmt_check->execute();
            $user_check = $stmt_check->fetch(PDO::FETCH_ASSOC);
            if ($user_check) {
                error_log("DEBUG update_user - Verification: vip_date after update = " . $user_check['vip_date']);
            }
        } catch (PDOException $e) {
            error_log("DEBUG update_user - Error verifying update: " . $e->getMessage());
        }
    ?>
        <script type="text/javascript">
            // بررسی مجدد قبل از redirect
            console.log('Update result: success');
            alert('تغییرات با موفقیت ذخیره شد!');
            // کمی تاخیر برای اطمینان از ذخیره شدن
            setTimeout(function() {
                window.location = "users.php?user_updated&userid=<?= $userid ?>";
            }, 500);
        </script>
    <?php } else { ?>
        <script type="text/javascript">
            console.log('Update result: failed');
            console.log('Userid: <?= $userid ?>');
            console.log('VIP Status: <?= $vip_status ?>');
            console.log('VIP Days: <?= $vip_days ?>');
            alert('خطا در به‌روزرسانی اطلاعات کاربر.\n\nلطفاً:\n1. به صفحه direct_test_vip.php بروید و تست کنید\n2. لاگ خطاها را بررسی کنید\n3. به صفحه debug_vip.php بروید');
            // هدایت به صفحه تست مستقیم
            setTimeout(function() {
                window.location = "direct_test_vip.php?userid=<?= $userid ?>";
            }, 2000);
        </script>
<?php }
} ?>

<?php if (isset($_GET['user_updated'])) { ?>
    <div id="alert1" class="my-3  block  text-left text-white bg-green-500 h-12 flex items-center justify-center p-4 rounded-md relative" role="alert">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="flex-shrink-0 w-6 h-6 mx-2 stroke-current">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9">
            </path>
        </svg>
        اطلاعات کاربر با موفقیت به‌روزرسانی شد.
        <button onclick="closeAlert()" class="absolute bg-transparent text-2xl font-semibold leading-none right-0 top-0 mt-3 mr-6 outline-none focus:outline-none">
            <span>×</span>
        </button>
    </div>
<?php } ?>

<?php if (isset($_GET['user_update_error'])) { ?>
    <div id="alert1" class="my-3  block  text-left text-white bg-red-500 h-12 flex items-center justify-center p-4 rounded-md relative" role="alert">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="flex-shrink-0 w-6 h-6 mx-2 stroke-current">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9">
            </path>
        </svg>
        مشکلی در به‌روزرسانی اطلاعات کاربر بوجود آمده است
        <button onclick="closeAlert()" class="absolute bg-transparent text-2xl font-semibold leading-none right-0 top-0 mt-3 mr-6 outline-none focus:outline-none">
            <span>×</span>
        </button>
    </div>
<?php } ?>