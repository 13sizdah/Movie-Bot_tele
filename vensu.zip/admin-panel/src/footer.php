<?php
if (!defined('INDEX')) {
    die('403-Forbidden Access');
}
?>
<script>
    function closeAlert() {
        var element = document.getElementById("alert1");
        element.classList.add("hidden");
    }
</script>

</html>