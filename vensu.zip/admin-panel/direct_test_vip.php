<?php
// تست مستقیم به‌روزرسانی VIP بدون redirect
define('INDEX', true);
ob_start();
session_start();

// بررسی اینکه آیا کاربر لاگین است
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

require_once 'db.php';
require_once 'src/func.php';

// بررسی اینکه آیا $db تعریف شده است
if (!isset($db)) {
    die('❌ اتصال به دیتابیس برقرار نشده است.');
}

$userid = isset($_POST['userid']) ? intval($_POST['userid']) : (isset($_GET['userid']) ? intval($_GET['userid']) : 0);
$vip_status = isset($_POST['vip_status']) ? intval($_POST['vip_status']) : 0;
$vip_days = isset($_POST['vip_days']) ? intval($_POST['vip_days']) : 30;

$result_message = '';
$debug_info = [];

if ($userid > 0 && isset($_POST['test_update'])) {
    // دریافت اطلاعات کاربر فعلی
    try {
        $sql = "SELECT * FROM sp_users WHERE userid=:userid LIMIT 1";
        $stmt = $db->prepare($sql);
        $stmt->bindValue(':userid', $userid, PDO::PARAM_INT);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            $debug_info['before_update'] = [
                'vip_date' => $user['vip_date'],
                'name' => $user['name']
            ];
            
            // محاسبه vip_date جدید
            if ($vip_status == 1) {
                if ($vip_days > 0) {
                    $vip_date = time() + ($vip_days * 86400);
                } else {
                    $vip_date = time() + (30 * 86400);
                }
            } else {
                $vip_date = 0;
            }
            
            $debug_info['calculated_vip_date'] = $vip_date;
            
            // به‌روزرسانی مستقیم در دیتابیس
            $sql_update = "UPDATE sp_users SET vip_date=:vip_date WHERE userid=:userid";
            $stmt_update = $db->prepare($sql_update);
            $stmt_update->bindValue(':vip_date', (string)$vip_date, PDO::PARAM_STR);
            $stmt_update->bindValue(':userid', $userid, PDO::PARAM_INT);
            $update_result = $stmt_update->execute();
            
            $debug_info['update_result'] = $update_result;
            $debug_info['affected_rows'] = $stmt_update->rowCount();
            
            // بررسی مجدد
            $sql_check = "SELECT vip_date FROM sp_users WHERE userid=:userid LIMIT 1";
            $stmt_check = $db->prepare($sql_check);
            $stmt_check->bindValue(':userid', $userid, PDO::PARAM_INT);
            $stmt_check->execute();
            $user_after = $stmt_check->fetch(PDO::FETCH_ASSOC);
            
            $debug_info['after_update'] = [
                'vip_date' => $user_after['vip_date']
            ];
            
            if ($update_result && $user_after && $user_after['vip_date'] == (string)$vip_date) {
                $result_message = '✅ به‌روزرسانی با موفقیت انجام شد!';
                $result_class = 'success';
            } else {
                $result_message = '❌ به‌روزرسانی انجام نشد یا مقدار تغییر نکرد!';
                $result_class = 'error';
            }
        } else {
            $result_message = '❌ کاربر یافت نشد!';
            $result_class = 'error';
        }
    } catch (PDOException $e) {
        $result_message = '❌ خطا: ' . $e->getMessage();
        $result_class = 'error';
        $debug_info['error'] = $e->getMessage();
    }
}

// دریافت اطلاعات کاربر برای نمایش
$user_info = null;
if ($userid > 0) {
    try {
        $sql = "SELECT * FROM sp_users WHERE userid=:userid LIMIT 1";
        $stmt = $db->prepare($sql);
        $stmt->bindValue(':userid', $userid, PDO::PARAM_INT);
        $stmt->execute();
        $user_info = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // ignore
    }
}

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تست مستقیم VIP</title>
    <style>
        body {
            font-family: Tahoma, Arial, sans-serif;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            border-bottom: 2px solid #4CAF50;
            padding-bottom: 10px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="number"], select {
            width: 300px;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            background: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background: #45a049;
        }
        .result {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .success {
            background: #4CAF50;
            color: white;
        }
        .error {
            background: #f44336;
            color: white;
        }
        .info {
            background: #2196F3;
            color: white;
        }
        .debug-section {
            margin-top: 30px;
            padding: 15px;
            background: #f9f9f9;
            border-radius: 4px;
            border-left: 4px solid #4CAF50;
        }
        .debug-section h2 {
            margin-top: 0;
            color: #4CAF50;
        }
        .info-item {
            margin: 10px 0;
            padding: 8px;
            background: white;
            border-radius: 4px;
        }
        .info-label {
            font-weight: bold;
            color: #666;
        }
        .info-value {
            color: #333;
            margin-top: 5px;
        }
        pre {
            background: #f4f4f4;
            padding: 10px;
            border-radius: 4px;
            overflow-x: auto;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🧪 تست مستقیم به‌روزرسانی VIP</h1>
        <p style="color: #666;">این صفحه مستقیماً در دیتابیس می‌نویسد بدون استفاده از توابع</p>
        
        <?php if (!empty($result_message)): ?>
            <div class="result <?= $result_class ?>">
                <?= $result_message ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="userid">شناسه کاربر (userid):</label>
                <input type="number" name="userid" id="userid" value="<?= $userid ?>" required>
            </div>
            
            <div class="form-group">
                <label for="vip_status">وضعیت VIP:</label>
                <select name="vip_status" id="vip_status">
                    <option value="0" <?= $vip_status == 0 ? 'selected' : '' ?>>غیرفعال</option>
                    <option value="1" <?= $vip_status == 1 ? 'selected' : '' ?>>فعال</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="vip_days">تعداد روزها (اگر فعال است):</label>
                <input type="number" name="vip_days" id="vip_days" value="<?= $vip_days ?>" min="1">
            </div>
            
            <button type="submit" name="test_update">تست به‌روزرسانی</button>
        </form>
        
        <?php if ($user_info): ?>
            <div class="debug-section">
                <h2>📊 اطلاعات کاربر فعلی</h2>
                <div class="info-item">
                    <span class="info-label">نام:</span>
                    <div class="info-value"><?= htmlspecialchars($user_info['name']) ?></div>
                </div>
                <div class="info-item">
                    <span class="info-label">userid:</span>
                    <div class="info-value"><?= $user_info['userid'] ?></div>
                </div>
                <div class="info-item">
                    <span class="info-label">vip_date (فعلی):</span>
                    <div class="info-value"><?= htmlspecialchars($user_info['vip_date']) ?></div>
                </div>
                <div class="info-item">
                    <span class="info-label">vip_date (تبدیل به عدد):</span>
                    <div class="info-value"><?= intval($user_info['vip_date']) ?></div>
                </div>
                <div class="info-item">
                    <span class="info-label">زمان فعلی:</span>
                    <div class="info-value"><?= time() ?></div>
                </div>
                <div class="info-item">
                    <span class="info-label">VIP فعال است؟</span>
                    <div class="info-value <?= (intval($user_info['vip_date']) > time()) ? 'success' : 'error' ?>">
                        <?= (intval($user_info['vip_date']) > time()) ? '✅ بله' : '❌ خیر' ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($debug_info)): ?>
            <div class="debug-section">
                <h2>🔍 اطلاعات دیباگ</h2>
                <pre><?= print_r($debug_info, true) ?></pre>
            </div>
        <?php endif; ?>
        
        <div class="debug-section" style="margin-top: 30px;">
            <h2>📝 نحوه استفاده</h2>
            <ol>
                <li>شناسه کاربر (userid) را وارد کنید</li>
                <li>وضعیت VIP را انتخاب کنید</li>
                <li>تعداد روزها را وارد کنید (اگر فعال است)</li>
                <li>روی "تست به‌روزرسانی" کلیک کنید</li>
                <li>نتیجه را بررسی کنید</li>
            </ol>
            <p><strong>نکته:</strong> این صفحه مستقیماً در دیتابیس می‌نویسد و از توابع استفاده نمی‌کند. اگر اینجا کار کرد، مشکل از توابع است.</p>
        </div>
    </div>
</body>
</html>

