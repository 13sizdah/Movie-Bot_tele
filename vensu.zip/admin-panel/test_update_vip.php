<?php
// صفحه تست برای به‌روزرسانی VIP
define('INDEX', true);
ob_start();
session_start();

// بررسی اینکه آیا کاربر لاگین است
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

require_once 'db.php';
require_once 'src/func.php';

// اتصال به دیتابیس
try {
    $db = new PDO(
        "mysql:host=" . HOST . ";dbname=" . DBNAME . ";charset=utf8mb4",
        USERNAME,
        PASSWORD,
        array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4")
    );
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("خطا در اتصال به دیتابیس: " . $e->getMessage());
}

$userid = isset($_POST['userid']) ? intval($_POST['userid']) : 0;
$vip_status = isset($_POST['vip_status']) ? intval($_POST['vip_status']) : 0;
$vip_days = isset($_POST['vip_days']) ? intval($_POST['vip_days']) : 0;

if ($userid > 0) {
    // دریافت اطلاعات کاربر فعلی
    try {
        $sql = "SELECT * FROM sp_users WHERE userid=:userid LIMIT 1";
        $stmt = $db->prepare($sql);
        $stmt->bindValue(':userid', $userid, PDO::PARAM_INT);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            // استفاده از تابع update_user_by_userid
            $result = update_user_by_userid(
                $userid,
                $user['name'],
                $user['phone'],
                $user['verified'],
                $vip_status,
                $vip_days
            );
            
            if ($result) {
                header("Location: debug_vip.php?userid=" . $userid . "&success=1");
            } else {
                header("Location: debug_vip.php?userid=" . $userid . "&error=update_failed");
            }
        } else {
            header("Location: debug_vip.php?userid=" . $userid . "&error=user_not_found");
        }
    } catch (PDOException $e) {
        error_log("Error in test_update_vip: " . $e->getMessage());
        header("Location: debug_vip.php?userid=" . $userid . "&error=" . urlencode($e->getMessage()));
    }
} else {
    header("Location: debug_vip.php?error=invalid_userid");
}
exit;

