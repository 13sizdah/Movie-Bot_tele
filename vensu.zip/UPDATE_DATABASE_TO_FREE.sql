-- ============================================================
-- اسکریپت به‌روزرسانی دیتابیس - تبدیل همه محتواها به رایگان
-- ============================================================
-- این اسکریپت تمام محتواهای VIP را به رایگان تبدیل می‌کند
-- و حالت VIP را در تنظیمات غیرفعال می‌کند
-- ============================================================

-- 1. تبدیل همه محتواهای type='vip' به type='free'
UPDATE sp_files 
SET type='free' 
WHERE type='vip';

-- نمایش تعداد محتواهای به‌روزرسانی شده
SELECT 
    COUNT(*) as updated_count,
    'محتواهای VIP به رایگان تبدیل شدند' as message
FROM sp_files 
WHERE type='free';

-- 2. غیرفعال کردن حالت VIP در تنظیمات
-- اگر تنظیم وجود دارد، آن را به‌روزرسانی کن
UPDATE sp_options 
SET value='0' 
WHERE name='enable_vip_mode';

-- اگر تنظیم وجود ندارد، آن را اضافه کن
INSERT INTO sp_options (name, value) 
VALUES ('enable_vip_mode', '0')
ON DUPLICATE KEY UPDATE value='0';

-- 3. نمایش آمار نهایی
SELECT 
    (SELECT COUNT(*) FROM sp_files WHERE type='free') as free_count,
    (SELECT COUNT(*) FROM sp_files WHERE type='vip') as vip_count,
    (SELECT COUNT(*) FROM sp_files) as total_count;

-- ============================================================
-- بررسی نتیجه
-- ============================================================
-- بعد از اجرای این اسکریپت:
-- 1. همه محتواها باید type='free' داشته باشند
-- 2. تنظیم enable_vip_mode باید '0' باشد
-- 3. هیچ محتوای VIP نباید باقی بماند
-- ============================================================

