# راهنمای ایجاد کاربر ادمین

این فایل راهنمای ایجاد کاربر ادمین در سیستم مدیریت فیلم و سریال است.

## 📋 فایل‌های موجود

1. **`CREATE_ADMIN_USER.sql`** - فایل SQL برای ایجاد ادمین پیش‌فرض
2. **`admin-panel/generate_admin_hash.php`** - فایل PHP برای تولید hash پسورد سفارشی

## 🚀 روش 1: استفاده از ادمین پیش‌فرض

### مراحل:

1. فایل `CREATE_ADMIN_USER.sql` را در phpMyAdmin یا هر ابزار مدیریت دیتابیس اجرا کنید
2. یا از دستور mysql استفاده کنید:
   ```bash
   mysql -u username -p database_name < CREATE_ADMIN_USER.sql
   ```

### اطلاعات ورود پیش‌فرض:

- **Username:** `admin`
- **Password:** `admin123`

⚠️ **هشدار امنیتی:** بعد از اولین ورود، حتماً پسورد را تغییر دهید!

## 🔧 روش 2: ایجاد ادمین با پسورد سفارشی

اگر می‌خواهید پسورد دیگری استفاده کنید:

### مراحل:

1. فایل `admin-panel/generate_admin_hash.php` را در مرورگر باز کنید
   - URL: `https://your-domain.com/admin-panel/generate_admin_hash.php`
2. پسورد مورد نظر خود را در متغیر `$password` وارد کنید
3. Hash تولید شده را کپی کنید
4. فایل `CREATE_ADMIN_USER.sql` را باز کنید
5. Hash موجود را با Hash جدید جایگزین کنید
6. فایل SQL را در دیتابیس اجرا کنید

### مثال:

```php
// در generate_admin_hash.php
$password = 'my_secure_password_123';
```

سپس Hash تولید شده را در SQL استفاده کنید:

```sql
INSERT INTO `sp_admins` (`username`, `password`) VALUES
('admin', 'HASH_PRODUCED_HERE');
```

## 📝 ایجاد ادمین جدید از طریق SQL مستقیم

می‌توانید مستقیماً در phpMyAdmin یا هر ابزار مدیریت دیتابیس، کوئری زیر را اجرا کنید:

```sql
-- حذف ادمین قبلی (اگر وجود دارد)
DELETE FROM `sp_admins` WHERE `username` = 'admin';

-- ایجاد ادمین جدید
INSERT INTO `sp_admins` (`username`, `password`) VALUES
('admin', '$2y$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy');
```

⚠️ **توجه:** Hash بالا برای پسورد `admin123` است. برای پسوردهای دیگر، از `generate_admin_hash.php` استفاده کنید.

## 🔒 نکات امنیتی

1. **تغییر پسورد:** بعد از اولین ورود، حتماً پسورد را از پنل مدیریت تغییر دهید
2. **حذف فایل تولید Hash:** بعد از استفاده، فایل `generate_admin_hash.php` را حذف کنید
3. **استفاده از پسورد قوی:** از پسوردهای پیچیده و قوی استفاده کنید
4. **محدود کردن دسترسی:** فقط به کاربران مورد اعتماد دسترسی ادمین بدهید

## ✅ بررسی ایجاد ادمین

پس از اجرای فایل SQL، می‌توانید با کوئری زیر بررسی کنید:

```sql
SELECT * FROM `sp_admins` WHERE `username` = 'admin';
```

باید یک ردیف با username `admin` نمایش داده شود.

## 🐛 رفع مشکلات

### خطا: "Duplicate entry"
- این خطا زمانی رخ می‌دهد که ادمین با username `admin` قبلاً وجود داشته باشد
- ابتدا ادمین قبلی را حذف کنید: `DELETE FROM sp_admins WHERE username = 'admin';`

### خطا: "Access denied"
- مطمئن شوید که کاربر دیتابیس دسترسی INSERT و DELETE دارد

### خطا در ورود: "رمز وارد شده اشتباه می باشد"
- مطمئن شوید که Hash پسورد به درستی در دیتابیس ذخیره شده است
- از `generate_admin_hash.php` برای تولید Hash جدید استفاده کنید

---

**نسخه:** 1.0.0  
**تاریخ:** 2024  
**وضعیت:** ✅ آماده استفاده

